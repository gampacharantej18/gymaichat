"""Optional standalone Streamlit chatbot using Groq via LangChain."""

import os

import streamlit as st
from dotenv import load_dotenv
from langchain_groq import ChatGroq

load_dotenv()


def get_secret(name: str, default: str = "") -> str:
    """Read a value from Streamlit Secrets first, then environment variables."""
    try:
        value = st.secrets.get(name)
        if value:
            return str(value)
    except Exception:
        # Streamlit Secrets is not available during ordinary local execution.
        pass
    return os.getenv(name, default)


def create_model() -> ChatGroq:
    api_key = get_secret("GROQ_API_KEY")
    if not api_key:
        raise RuntimeError(
            "GROQ_API_KEY is missing. Add it to .env locally or Streamlit Secrets when deployed."
        )

    return ChatGroq(
        model=get_secret("GROQ_MODEL", "llama-3.3-70b-versatile"),
        groq_api_key=api_key,
        temperature=0.6,
    )


def chat_interface(model: ChatGroq) -> None:
    st.title("Chat with your AI Gym Trainer")
    st.write("Ask questions about fitness, nutrition, or your workout plan.")

    if "messages" not in st.session_state:
        st.session_state.messages = []

    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    if prompt := st.chat_input("What would you like to know?"):
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)

        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                response = model.invoke(
                    [
                        (
                            "system",
                            "You are an AI Gym Trainer. Give safe, personalized advice about "
                            "fitness, nutrition, and workouts. Remind users to consult a qualified "
                            "health professional for medical concerns.",
                        ),
                        *[
                            (message["role"], message["content"])
                            for message in st.session_state.messages
                        ],
                    ]
                )
                st.markdown(response.content)

        st.session_state.messages.append(
            {"role": "assistant", "content": response.content}
        )


if __name__ == "__main__":
    try:
        chat_interface(create_model())
    except RuntimeError as error:
        st.error(str(error))
