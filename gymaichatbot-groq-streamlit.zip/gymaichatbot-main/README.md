# AI Gym Trainer Chatbot

A Streamlit AI gym trainer that creates a personalized fitness and nutrition plan and supports follow-up questions. The project uses **Groq** through LangChain and is ready for deployment on Streamlit Community Cloud.

## Features

- Personalized plan based on age, gender, height, weight, activity, experience, injuries, and goal
- Follow-up chat with the same profile and conversation history
- Groq model configuration through an environment variable
- Local `.env` support and Streamlit Cloud Secrets support
- Dark, responsive Streamlit interface

## Project structure

```text
.
├── app.py              # Main personalized trainer application
├── chatbot.py          # Optional standalone chatbot module
├── requirements.txt    # Python dependencies
├── .env.example        # Safe environment-variable template
├── .gitignore
└── README.md
```

## Run locally

1. Create a Groq API key at [console.groq.com/keys](https://console.groq.com/keys).
2. Copy the environment template and add your key:

   ```bash
   cp .env.example .env
   ```

3. Install dependencies:

   ```bash
   python -m venv .venv
   source .venv/bin/activate       # Windows: .venv\\Scripts\\activate
   pip install -r requirements.txt
   ```

4. Start the main app:

   ```bash
   streamlit run app.py
   ```

The app opens at `http://localhost:8501`.

## Deploy on Streamlit Community Cloud

1. Create a GitHub repository and upload the project files.
2. In Streamlit Community Cloud, choose **Deploy an app** and select the repository.
3. Set the main file to `app.py`.
4. Open the app's **Settings → Secrets** panel and add:

   ```toml
   GROQ_API_KEY = "your_groq_api_key_here"
   GROQ_MODEL = "llama-3.3-70b-versatile"
   ```

5. Save the secrets and redeploy.

Do not commit `.env` or a real API key to GitHub. The included `.gitignore` excludes `.env`.

## Change the model

The default model is `llama-3.3-70b-versatile`. To use another model available in your Groq account, change `GROQ_MODEL` in `.env` or Streamlit Secrets. No Python code changes are required.

## Safety note

This application provides general fitness and nutrition information, not medical diagnosis or treatment. Users with injuries, medical conditions, eating disorders, or other health concerns should consult a qualified healthcare professional before following a training or nutrition plan.
